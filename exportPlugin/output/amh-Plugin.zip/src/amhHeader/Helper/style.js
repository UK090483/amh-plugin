const style = {
	center: {
		display: "flex",
		alignItems: "center",
		justifyContent: "center"
	},
	row: {
		display: "flex",
		alignItems: "center",
		justifyContent: "center",
		height: 35
	}
};

export default style;
